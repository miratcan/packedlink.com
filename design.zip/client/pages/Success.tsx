import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Copy, Check, Share2 } from "lucide-react";

interface LinkItem {
  id: string;
  url: string;
  title: string;
  description: string;
}

interface ListData {
  id: string;
  title: string;
  description: string;
  creatorName: string;
  creatorHandle: string;
  links: LinkItem[];
}

export default function Success() {
  const navigate = useNavigate();
  const [list, setList] = useState<ListData | null>(null);
  const [copied, setCopied] = useState<"public" | "manage" | null>(null);

  useEffect(() => {
    const saved = sessionStorage.getItem("kaydetList");
    if (saved) {
      setList(JSON.parse(saved));
    } else {
      navigate("/builder");
    }
  }, [navigate]);

  if (!list) return null;

  const publicUrl = `${window.location.origin}/list/${list.id}`;
  const manageUrl = `${window.location.origin}/list/${list.id}?auth=${list.id}-manage`;

  const copyToClipboard = (text: string, type: "public" | "manage") => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="min-h-screen bg-kaydet-cream">
      {/* Header */}
      <header className="border-b border-kaydet-border bg-kaydet-bg-warm">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-[4px] bg-gradient-to-br from-kaydet-accent to-kaydet-accent-hover"></div>
              <span className="font-semibold text-kaydet-text-primary">kaydet.link</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-12">
        {/* Success Message */}
        <div className="mb-8 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-kaydet-accent/10 mb-4">
            <Check className="w-8 h-8 text-kaydet-accent" />
          </div>
          <h1 className="text-4xl font-semibold text-kaydet-text-primary mb-2">
            Tebrikler!
          </h1>
          <p className="text-lg text-kaydet-text-secondary">
            Listeniz başarıyla yayınlandı. Şimdi linki paylaşabilirsin.
          </p>
        </div>

        {/* Links Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Public Link */}
          <div className="bg-white rounded-[4px] border border-kaydet-border p-6">
            <h2 className="font-semibold text-kaydet-text-primary mb-4">
              Herkese paylaşılacak link
            </h2>
            <div className="mb-4 p-4 bg-kaydet-cream rounded-[4px] break-all text-sm text-kaydet-text-secondary">
              {publicUrl}
            </div>
            <button
              onClick={() => copyToClipboard(publicUrl, "public")}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 rounded-[4px] bg-kaydet-accent text-white font-medium hover:bg-kaydet-accent-hover transition-colors"
            >
              {copied === "public" ? (
                <>
                  <Check className="w-4 h-4" />
                  Kopyalandı
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Linki kopyala
                </>
              )}
            </button>
          </div>

          {/* Management Link */}
          <div className="bg-white rounded-[4px] border border-kaydet-border p-6">
            <h2 className="font-semibold text-kaydet-text-primary mb-4">
              Listenizi yönetmek için
            </h2>
            <div className="mb-4">
              <p className="text-xs text-kaydet-text-secondary mb-2">
                Bu link sadece sana, başka kimse bunu görmemelidir. Bu linkle listeyi yönetebilirsin.
              </p>
              <div className="p-4 bg-kaydet-cream rounded-[4px] break-all text-sm text-kaydet-text-secondary">
                {manageUrl}
              </div>
            </div>
            <button
              onClick={() => copyToClipboard(manageUrl, "manage")}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2 rounded-[4px] border border-kaydet-border text-kaydet-text-primary font-medium hover:bg-kaydet-cream transition-colors"
            >
              {copied === "manage" ? (
                <>
                  <Check className="w-4 h-4" />
                  Kopyalandı
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Yönetim linkini kopyala
                </>
              )}
            </button>
          </div>
        </div>

        {/* List Preview */}
        <div className="bg-white rounded-[4px] border border-kaydet-border overflow-hidden mb-8">
          <div className="bg-kaydet-dashboard-blue h-32"></div>
          <div className="p-6">
            {list.creatorName && (
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-full bg-kaydet-accent/20 flex items-center justify-center">
                  <span className="text-kaydet-accent font-semibold">
                    {list.creatorName.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div>
                  <p className="font-semibold text-kaydet-text-primary">
                    {list.creatorName}
                  </p>
                  {list.creatorHandle && (
                    <p className="text-sm text-kaydet-text-secondary">
                      {list.creatorHandle}
                    </p>
                  )}
                </div>
              </div>
            )}

            <h3 className="text-2xl font-semibold text-kaydet-text-primary mb-2">
              {list.title}
            </h3>

            {list.description && (
              <p className="text-kaydet-text-secondary mb-6">
                {list.description}
              </p>
            )}

            <div className="space-y-3">
              {list.links.map((link) => (
                <div key={link.id} className="flex gap-3">
                  <div className="w-1 bg-kaydet-accent rounded-full flex-shrink-0"></div>
                  <div className="flex-1 min-w-0">
                    <p className="text-kaydet-accent font-medium text-sm">
                      {link.title}
                    </p>
                    {link.description && (
                      <p className="text-xs text-kaydet-text-secondary mt-1">
                        {link.description}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Link
            to={publicUrl}
            className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 rounded-[4px] bg-kaydet-accent text-white font-medium hover:bg-kaydet-accent-hover transition-colors"
          >
            Listeyi görüntüle
            <Share2 className="w-4 h-4" />
          </Link>
          <Link
            to="/"
            className="flex-1 inline-flex items-center justify-center px-6 py-3 rounded-[4px] border border-kaydet-border text-kaydet-text-primary font-medium hover:bg-kaydet-light-bg transition-colors"
          >
            Ana sayfaya dön
          </Link>
        </div>
      </div>
    </div>
  );
}
