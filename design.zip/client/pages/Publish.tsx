import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";

interface LinkItem {
  id: string;
  url: string;
  title: string;
  description: string;
}

interface ListData {
  id: string;
  title: string;
  description: string;
  creatorName: string;
  creatorHandle: string;
  links: LinkItem[];
}

export default function Publish() {
  const navigate = useNavigate();
  const [list, setList] = useState<ListData | null>(null);
  const [isPublishing, setIsPublishing] = useState(false);

  useEffect(() => {
    const saved = sessionStorage.getItem("kaydetList");
    if (saved) {
      setList(JSON.parse(saved));
    } else {
      navigate("/builder");
    }
  }, [navigate]);

  const handlePublish = async () => {
    setIsPublishing(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    navigate("/success");
  };

  if (!list) return null;

  return (
    <div className="min-h-screen bg-kaydet-cream">
      {/* Header */}
      <header className="border-b border-kaydet-border bg-kaydet-bg-warm">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-[4px] bg-gradient-to-br from-kaydet-accent to-kaydet-accent-hover"></div>
              <span className="font-semibold text-kaydet-text-primary">kaydet.link</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-[4px] border border-kaydet-border overflow-hidden">
          {/* Preview Section */}
          <div className="p-8 border-b border-kaydet-border">
            <h1 className="text-3xl font-semibold text-kaydet-text-primary mb-2">
              Listeyi yayınla
            </h1>
            <p className="text-kaydet-text-secondary">
              Listeni yayınlamadan önce bir daha kontrol et. Yayınladıktan sonra linki paylaşabilirsin.
            </p>
          </div>

          <div className="p-8">
            {/* List Preview */}
            <div className="mb-8 p-6 bg-kaydet-cream rounded-[4px]">
              <div className="flex items-start gap-4 mb-6">
                {list.creatorName && (
                  <div className="w-12 h-12 rounded-full bg-kaydet-accent/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-kaydet-accent font-semibold">
                      {list.creatorName.charAt(0).toUpperCase()}
                    </span>
                  </div>
                )}
                <div className="flex-1">
                  {list.creatorName && (
                    <p className="font-semibold text-kaydet-text-primary">
                      {list.creatorName}
                    </p>
                  )}
                  {list.creatorHandle && (
                    <p className="text-sm text-kaydet-text-secondary">
                      {list.creatorHandle}
                    </p>
                  )}
                </div>
              </div>

              <h2 className="text-2xl font-semibold text-kaydet-text-primary mb-2">
                {list.title}
              </h2>

              {list.description && (
                <p className="text-kaydet-text-secondary mb-6">
                  {list.description}
                </p>
              )}

              <div className="space-y-3">
                {list.links.map((link) => (
                  <div key={link.id} className="flex gap-3">
                    <div className="w-1 bg-kaydet-accent rounded-full flex-shrink-0"></div>
                    <div className="flex-1 min-w-0">
                      <p className="text-kaydet-accent font-medium text-sm">
                        {link.title}
                      </p>
                      {link.description && (
                        <p className="text-xs text-kaydet-text-secondary mt-1">
                          {link.description}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
              <div className="p-4 bg-kaydet-cream rounded-[4px]">
                <p className="text-sm text-kaydet-text-secondary mb-1">Linkler</p>
                <p className="text-2xl font-semibold text-kaydet-text-primary">
                  {list.links.length}
                </p>
              </div>
              <div className="p-4 bg-kaydet-light-bg rounded-[4px]">
                <p className="text-sm text-kaydet-text-secondary mb-1">
                  30 gün içinde sona erecek
                </p>
                <p className="text-sm text-kaydet-text-primary font-medium">
                  Listenin yaşam süresi
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-4">
              <button
                onClick={() => navigate("/builder")}
                className="flex-1 px-6 py-3 rounded-[4px] border border-kaydet-border text-kaydet-text-primary font-medium hover:bg-kaydet-light-bg transition-colors"
              >
                Geri dön
              </button>
              <button
                onClick={handlePublish}
                disabled={isPublishing}
                className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3 rounded-[4px] bg-kaydet-accent text-white font-medium hover:bg-kaydet-accent-hover transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isPublishing ? "Yayınlanıyor..." : "Yayınla"}
                {!isPublishing && <ArrowRight className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
