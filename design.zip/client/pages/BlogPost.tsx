import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Calendar, User, Share2 } from "lucide-react";

interface BlogPostData {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  author: string;
  date: string;
  category: string;
  readingTime: number;
}

const blogPostsData: Record<string, BlogPostData> = {
  "getting-started-with-link-lists": {
    id: "1",
    slug: "getting-started-with-link-lists",
    title: "Başlamak: Link Listelerinin Gücü",
    excerpt:
      "Link listelerinin dijital dünyada nasıl hayatınızı daha organize hale getirebileceğini keşfedin.",
    author: "Ahmet Yılmaz",
    date: "15 Ocak 2024",
    category: "Rehber",
    readingTime: 5,
    content: `
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>

      <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

      <h3>Link Listelerinin Avantajları</h3>
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>

      <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>

      <h3>Başlamak İçin İlk Adımlar</h3>
      <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>

      <p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>
    `,
  },
  "organizing-your-digital-resources": {
    id: "2",
    slug: "organizing-your-digital-resources",
    title: "Dijital Kaynaklarınızı Organize Etme",
    excerpt:
      "Web'de bulunan kaynakları etkili bir şekilde organize etmek için en iyi uygulamalar.",
    author: "Fatih Kaya",
    date: "12 Ocak 2024",
    category: "İpuçları",
    readingTime: 7,
    content: `
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis volutpat est velit egestas duis.</p>

      <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</p>

      <h3>Etkili Organizasyon Stratejileri</h3>
      <p>Similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus.</p>

      <p>Omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae itaque earum rerum hic tenetur a sapiente delectus.</p>

      <h3>Teknolojinin Rolü</h3>
      <p>Ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    `,
  },
  "sharing-knowledge-with-your-network": {
    id: "3",
    slug: "sharing-knowledge-with-your-network",
    title: "Ağınızla Bilgi Paylaşmak",
    excerpt:
      "Kurumlar ve bireyler için öğrenme kaynaklarının değeri. Nasıl etkili bir şekilde bilgi paylaşılır?",
    author: "Zeynep Özdemir",
    date: "10 Ocak 2024",
    category: "İçgörüler",
    readingTime: 6,
    content: `
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>

      <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.</p>

      <h3>Bilgi Paylaşımının Gücü</h3>
      <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>

      <p>Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.</p>
    `,
  },
  "productivity-tools-for-modern-workers": {
    id: "4",
    slug: "productivity-tools-for-modern-workers",
    title: "Modern Çalışanlar için Verimlilik Araçları",
    excerpt:
      "Günlük görevlerinizde verimliliği artırmak için gerekli araçları keşfedin.",
    author: "Can Demir",
    date: "8 Ocak 2024",
    category: "Rehber",
    readingTime: 8,
    content: `
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>

      <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

      <h3>Verimlilik Araçlarının Seçimi</h3>
      <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</p>

      <p>Similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio.</p>
    `,
  },
  "the-future-of-content-curation": {
    id: "5",
    slug: "the-future-of-content-curation",
    title: "İçerik Seçkisinin Geleceği",
    excerpt:
      "Teknoloji ve yapay zeka, içerik seçkisini nasıl şekillendiriyor?",
    author: "Mert Uçar",
    date: "5 Ocak 2024",
    category: "İçgörüler",
    readingTime: 9,
    content: `
      <p>Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae itaque earum rerum hic tenetur a sapiente delectus.</p>

      <p>Ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>

      <h3>Yapay Zeka ve İçerik</h3>
      <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>

      <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.</p>
    `,
  },
  "best-practices-for-link-collection": {
    id: "6",
    slug: "best-practices-for-link-collection",
    title: "Link Koleksiyonu için En İyi Uygulamalar",
    excerpt:
      "Başlıklandırma, açıklama ve kategorileme yöntemleri. Linki listelerinizi maksimum etkinlik için optimize edin.",
    author: "Işık Aydın",
    date: "2 Ocak 2024",
    category: "Rehber",
    readingTime: 5,
    content: `
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra maecenas accumsan lacus vel facilisis volutpat.</p>

      <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.</p>

      <h3>En İyi Uygulamalar</h3>
      <p>Similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus.</p>

      <p>Omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae itaque earum rerum hic tenetur a sapiente delectus.</p>
    `,
  },
};

export default function BlogPost() {
  const { slug } = useParams<{ slug: string }>();
  const post = slug ? blogPostsData[slug] : null;

  if (!post) {
    return (
      <div className="min-h-screen bg-kaydet-cream">
        <header className="sticky top-0 z-50 border-b border-kaydet-border bg-kaydet-bg-warm">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex h-16 items-center justify-between">
              <Link
                to="/"
                className="flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:ring-offset-2 rounded-[4px]"
              >
                <div className="w-8 h-8 rounded-[4px] bg-gradient-to-br from-kaydet-accent to-kaydet-accent-hover"></div>
                <span className="font-semibold text-kaydet-text-primary">kaydet.link</span>
              </Link>
            </div>
          </div>
        </header>

        <div className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="text-center">
            <h1 className="text-2xl font-semibold text-kaydet-text-primary mb-2">
              Yazı bulunamadı
            </h1>
            <p className="text-kaydet-text-secondary mb-6">
              Aradığınız blog yazısı mevcut değil.
            </p>
            <Link
              to="/blog"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-[4px] bg-kaydet-accent text-white font-semibold border border-kaydet-accent-active hover:bg-kaydet-accent-hover active:bg-kaydet-accent-active transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Bloga dön
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-kaydet-cream">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-kaydet-border bg-kaydet-bg-warm">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link
              to="/"
              className="flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:ring-offset-2 rounded-[4px]"
            >
              <div className="w-8 h-8 rounded-[4px] bg-gradient-to-br from-kaydet-accent to-kaydet-accent-hover"></div>
              <span className="font-semibold text-kaydet-text-primary">kaydet.link</span>
            </Link>
            <Link
              to="/blog"
              className="inline-flex items-center gap-2 px-5 py-2 text-sm rounded-[4px] text-kaydet-text-primary hover:bg-kaydet-cream transition-colors focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:ring-offset-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Bloga dön
            </Link>
          </div>
        </div>
      </header>

      {/* Article */}
      <article className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8 py-12">
        {/* Meta Info */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-4 flex-wrap">
            <span className="inline-flex px-3 py-1 rounded-full text-xs font-semibold bg-kaydet-accent/10 text-kaydet-accent">
              {post.category}
            </span>
            <span className="text-xs text-kaydet-text-secondary">{post.readingTime} min okuma</span>
          </div>

          <h1 className="text-4xl sm:text-5xl font-semibold text-kaydet-text-primary mb-6">
            {post.title}
          </h1>

          <div className="flex items-center gap-6 text-sm text-kaydet-text-secondary pb-6 border-b border-kaydet-border">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-kaydet-accent/20 flex items-center justify-center text-xs font-semibold text-kaydet-accent">
                {post.author.charAt(0)}
              </div>
              <span>{post.author}</span>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>{post.date}</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="prose prose-sm sm:prose max-w-none mb-12 text-kaydet-text-primary">
          <div
            className="space-y-4"
            dangerouslySetInnerHTML={{
              __html: post.content
                .replace(/<h3>/g, '<h3 class="text-xl font-semibold text-kaydet-text-primary mt-6 mb-3">')
                .replace(/<p>/g, '<p class="text-kaydet-text-secondary leading-relaxed">')
                .replace(/<a /g, '<a class="text-kaydet-accent hover:text-kaydet-accent-hover" '),
            }}
          />
        </div>

        {/* CTA Section */}
        <div className="bg-kaydet-brown/5 rounded-[4px] border border-kaydet-border p-8 text-center">
          <h3 className="text-xl font-semibold text-kaydet-text-primary mb-3">
            Link listele oluşturmaya hazır mısın?
          </h3>
          <p className="text-kaydet-text-secondary mb-6">
            Bulduğun en iyi kaynakları organize et ve paylaş.
          </p>
          <Link
            to="/builder"
            className="inline-flex items-center justify-center gap-2 px-8 py-3 rounded-[4px] bg-kaydet-accent text-white font-semibold border border-kaydet-accent-active hover:bg-kaydet-accent-hover active:bg-kaydet-accent-active transition-colors focus:outline-none focus:ring-2 focus:ring-kaydet-accent-hover focus:ring-offset-2"
          >
            Hemen başla
          </Link>
        </div>

        {/* Related Posts Preview */}
        <div className="mt-16 pt-12 border-t border-kaydet-border">
          <h3 className="text-xl font-semibold text-kaydet-text-primary mb-6">
            Diğer yazılar
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Link
              to="/blog"
              className="group p-4 bg-white rounded-[4px] border border-kaydet-border hover:border-kaydet-accent hover:shadow-md transition-all"
            >
              <p className="text-sm font-semibold text-kaydet-accent group-hover:text-kaydet-accent-hover mb-2">
                Blog yazılarını keşfet
              </p>
              <p className="text-sm text-kaydet-text-secondary">
                Tüm blog yazılarına bak ve ilginizi çeken konuları bul.
              </p>
            </Link>
            <Link
              to="/builder"
              className="group p-4 bg-white rounded-[4px] border border-kaydet-border hover:border-kaydet-accent hover:shadow-md transition-all"
            >
              <p className="text-sm font-semibold text-kaydet-accent group-hover:text-kaydet-accent-hover mb-2">
                Şimdi başla
              </p>
              <p className="text-sm text-kaydet-text-secondary">
                Kendi link listeni oluştur ve kaynakları organize et.
              </p>
            </Link>
          </div>
        </div>
      </article>
    </div>
  );
}
