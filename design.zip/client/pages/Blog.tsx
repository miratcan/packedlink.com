import { Link } from "react-router-dom";
import { ArrowRight, Calendar, User } from "lucide-react";

interface BlogPost {
  id: string;
  slug: string;
  title: string;
  excerpt: string;
  author: string;
  date: string;
  category: string;
  readingTime: number;
}

const blogPosts: BlogPost[] = [
  {
    id: "1",
    slug: "getting-started-with-link-lists",
    title: "Başlamak: Link Listelerinin Gücü",
    excerpt:
      "Link listelerinin dijital dünyada nasıl hayatınızı daha organize hale getirebileceğini keşfedin. Kolaylık, açıklık ve erişilebilirlik hakkında bilgi edinin.",
    author: "Ahmet Yılmaz",
    date: "15 Ocak 2024",
    category: "Rehber",
    readingTime: 5,
  },
  {
    id: "2",
    slug: "organizing-your-digital-resources",
    title: "Dijital Kaynaklarınızı Organize Etme",
    excerpt:
      "Web'de bulunan kaynakları etkili bir şekilde organize etmek için en iyi uygulamalar. Üretkenliğinizi artırın ve bilgiye daha hızlı erişin.",
    author: "Fatih Kaya",
    date: "12 Ocak 2024",
    category: "İpuçları",
    readingTime: 7,
  },
  {
    id: "3",
    slug: "sharing-knowledge-with-your-network",
    title: "Ağınızla Bilgi Paylaşmak",
    excerpt:
      "Kurumlar ve bireyler için öğrenme kaynaklarının değeri. Nasıl etkili bir şekilde bilgi paylaşılır ve topluluğunuzu desteklersiniz?",
    author: "Zeynep Özdemir",
    date: "10 Ocak 2024",
    category: "İçgörüler",
    readingTime: 6,
  },
  {
    id: "4",
    slug: "productivity-tools-for-modern-workers",
    title: "Modern Çalışanlar için Verimlilik Araçları",
    excerpt:
      "Günlük görevlerinizde verimliliği artırmak için gerekli araçları keşfedin. Zaman yönetimi ve odaklanma konusunda pratik tavsiyeleri okuyun.",
    author: "Can Demir",
    date: "8 Ocak 2024",
    category: "Rehber",
    readingTime: 8,
  },
  {
    id: "5",
    slug: "the-future-of-content-curation",
    title: "İçerik Seçkisinin Geleceği",
    excerpt:
      "Teknoloji ve yapay zeka, içerik seçkisini nasıl şekillendiriyor? Gelecekteki trendleri ve fırsatları keşfedin.",
    author: "Mert Uçar",
    date: "5 Ocak 2024",
    category: "İçgörüler",
    readingTime: 9,
  },
  {
    id: "6",
    slug: "best-practices-for-link-collection",
    title: "Link Koleksiyonu için En İyi Uygulamalar",
    excerpt:
      "Başlıklandırma, açıklama ve kategorileme yöntemleri. Linki listelerinizi maksimum etkinlik için optimize edin.",
    author: "Işık Aydın",
    date: "2 Ocak 2024",
    category: "Rehber",
    readingTime: 5,
  },
];

export default function Blog() {
  const categories = [...new Set(blogPosts.map((post) => post.category))];

  return (
    <div className="min-h-screen bg-kaydet-cream">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-kaydet-border bg-kaydet-bg-warm">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link to="/" className="flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:ring-offset-2 rounded-[4px]">
              <div className="w-8 h-8 rounded-[4px] bg-gradient-to-br from-kaydet-accent to-kaydet-accent-hover"></div>
              <span className="font-semibold text-kaydet-text-primary">kaydet.link</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-kaydet-accent/5 to-kaydet-brown/5 border-b border-kaydet-border">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16">
          <h1 className="text-4xl sm:text-5xl font-semibold text-kaydet-text-primary mb-4">
            Blog
          </h1>
          <p className="text-lg text-kaydet-text-secondary max-w-2xl">
            Dijital dünyada nasıl daha verimli olacağınız, kaynakları nasıl yöneteceğiniz ve
            etkili bağlantılar kuracağınız hakkında ipuçları, rehberler ve içgörüler.
          </p>
        </div>
      </section>

      {/* Main Content */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <aside className="lg:col-span-1">
            <div className="sticky top-24 space-y-8">
              {/* Categories */}
              <div>
                <h3 className="text-sm font-semibold text-kaydet-text-primary uppercase tracking-wider mb-4">
                  Kategoriler
                </h3>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <button
                      key={category}
                      className="block w-full text-left px-3 py-2 rounded-[4px] text-sm text-kaydet-text-secondary hover:text-kaydet-accent hover:bg-kaydet-cream transition-colors"
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>

              {/* Stats */}
              <div className="bg-white rounded-[4px] border border-kaydet-border p-6">
                <h3 className="text-sm font-semibold text-kaydet-text-primary mb-4">
                  İstatistikler
                </h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-kaydet-text-secondary">Toplam yazı</span>
                    <span className="font-semibold text-kaydet-text-primary">
                      {blogPosts.length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-kaydet-text-secondary">Kategoriler</span>
                    <span className="font-semibold text-kaydet-text-primary">
                      {categories.length}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-kaydet-text-secondary">Ortalama okuma</span>
                    <span className="font-semibold text-kaydet-text-primary">
                      {Math.round(
                        blogPosts.reduce((sum, post) => sum + post.readingTime, 0) /
                          blogPosts.length
                      )}{" "}
                      min
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </aside>

          {/* Posts Grid */}
          <div className="lg:col-span-3">
            <div className="grid grid-cols-1 gap-8">
              {blogPosts.map((post) => (
                <Link
                  key={post.id}
                  to={`/blog/${post.slug}`}
                  className="group bg-white rounded-[4px] border border-kaydet-border p-6 hover:border-kaydet-accent hover:shadow-md transition-all"
                >
                  <div className="flex items-start justify-between gap-4 mb-3">
                    <span className="inline-flex px-3 py-1 rounded-full text-xs font-semibold bg-kaydet-accent/10 text-kaydet-accent">
                      {post.category}
                    </span>
                    <span className="text-xs text-kaydet-text-secondary whitespace-nowrap">
                      {post.readingTime} min
                    </span>
                  </div>

                  <h2 className="text-xl sm:text-2xl font-semibold text-kaydet-text-primary group-hover:text-kaydet-accent transition-colors mb-3">
                    {post.title}
                  </h2>

                  <p className="text-kaydet-text-secondary mb-4 line-clamp-2">
                    {post.excerpt}
                  </p>

                  <div className="flex items-center justify-between pt-4 border-t border-kaydet-border">
                    <div className="flex items-center gap-4 text-sm text-kaydet-text-secondary">
                      <div className="flex items-center gap-1">
                        <User className="w-4 h-4" />
                        {post.author}
                      </div>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {post.date}
                      </div>
                    </div>
                    <ArrowRight className="w-4 h-4 text-kaydet-accent group-hover:translate-x-1 transition-transform" />
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Footer CTA */}
      <section className="bg-kaydet-brown/5 border-t border-kaydet-border mt-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12 text-center">
          <h2 className="text-2xl sm:text-3xl font-semibold text-kaydet-text-primary mb-4">
            Hemen başla
          </h2>
          <p className="text-kaydet-text-secondary mb-6 max-w-2xl mx-auto">
            Link listelerinizi organize etmeye ve yönetmeye hazır mısınız?
          </p>
          <Link
            to="/builder"
            className="inline-flex items-center justify-center gap-2 px-8 py-3 rounded-[4px] bg-kaydet-accent text-white font-semibold border border-kaydet-accent-active hover:bg-kaydet-accent-hover active:bg-kaydet-accent-active transition-colors focus:outline-none focus:ring-2 focus:ring-kaydet-accent-hover focus:ring-offset-2"
          >
            Liste oluştur
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}
