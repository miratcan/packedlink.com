import { useParams, Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { Copy, Check, ArrowLeft } from "lucide-react";

interface LinkItem {
  id: string;
  url: string;
  title: string;
  description: string;
}

interface ListData {
  id: string;
  title: string;
  description: string;
  creatorName: string;
  creatorHandle: string;
  links: LinkItem[];
}

const fakeLists: Record<string, ListData> = {
  "abc123xyz": {
    id: "abc123xyz",
    title: "Web Geliştirme Kaynakları",
    description:
      "Web geliştirmede ihtiyaç duyabileceğin en kullanışlı kaynaklar, araçlar ve öğrenme materyalleri.",
    creatorName: "Ahmet",
    creatorHandle: "@ahmet_dev",
    links: [
      {
        id: "1",
        url: "https://developer.mozilla.org",
        title: "MDN Web Docs",
        description: "Mozilla tarafından sağlanan kapsamlı web geliştirme dokümantasyonu",
      },
      {
        id: "2",
        url: "https://tailwindcss.com",
        title: "Tailwind CSS",
        description: "Hızlı UI geliştirme için utility-first CSS framework",
      },
      {
        id: "3",
        url: "https://react.dev",
        title: "React Documentation",
        description: "Modern JavaScript kütüphanesi React'ın resmi dokümantasyonu",
      },
      {
        id: "4",
        url: "https://typescript.org",
        title: "TypeScript",
        description: "JavaScript'e tür güvenliği ekleyen, statik tür kontrol sistemi",
      },
      {
        id: "5",
        url: "https://vite.dev",
        title: "Vite",
        description: "Hızlı ve modern web projesi build aracı",
      },
    ],
  },
  "def456uvw": {
    id: "def456uvw",
    title: "Yazı Yazma ve İçerik Stratejisi",
    description:
      "İçerik oluşturma, editleme ve yayınlama süreçlerinde yardımcı olacak kaynaklar.",
    creatorName: "Zeynep",
    creatorHandle: "@zeynep_yazar",
    links: [
      {
        id: "1",
        url: "https://grammarly.com",
        title: "Grammarly",
        description: "İngilizce yazım ve dil kontrolü aracı",
      },
      {
        id: "2",
        url: "https://hemingwayapp.com",
        title: "Hemingway App",
        description: "Yazıyı daha basit ve okunur hale getirmeye yardımcı araç",
      },
      {
        id: "3",
        url: "https://unsplash.com",
        title: "Unsplash",
        description: "Ücretsiz, yüksek kaliteli fotoğraflar",
      },
    ],
  },
};

export default function PublicList() {
  const { id } = useParams<{ id: string }>();
  const [list, setList] = useState<ListData | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    // Load list from sessionStorage or use fake data (in a real app, this would come from an API)
    const saved = sessionStorage.getItem("kaydetList");
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.id === id) {
        setList(parsed);
        return;
      }
    }

    // Use fake data if available
    if (id && id in fakeLists) {
      setList(fakeLists[id]);
    }
  }, [id]);

  if (!list) {
    return (
      <div className="min-h-screen bg-kaydet-bg-warm">
        <header className="border-b border-kaydet-border">
          <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
            <div className="flex h-16 items-center justify-between">
              <Link to="/" className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-[4px] bg-gradient-to-br from-kaydet-accent to-kaydet-accent-hover"></div>
                <span className="font-semibold text-kaydet-text-primary">kaydet.link</span>
              </Link>
            </div>
          </div>
        </header>

        <div className="flex items-center justify-center min-h-[calc(100vh-64px)]">
          <div className="text-center">
            <h1 className="text-2xl font-semibold text-kaydet-text-primary mb-2">
              Liste bulunamadı
            </h1>
            <p className="text-kaydet-text-secondary mb-6">
              Bu liste kullanılamıyor veya silindi.
            </p>
            <Link
              to="/"
              className="inline-flex items-center gap-2 px-6 py-2 rounded-[4px] bg-kaydet-accent text-white font-medium hover:bg-kaydet-accent-hover transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Ana sayfaya dön
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const copyToClipboard = (url: string, linkTitle: string) => {
    navigator.clipboard.writeText(url);
    setCopied(linkTitle);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="min-h-screen bg-kaydet-bg-warm">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-kaydet-border bg-kaydet-bg-warm">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-[4px] bg-gradient-to-br from-kaydet-accent to-kaydet-accent-hover"></div>
              <span className="font-semibold text-kaydet-text-primary">kaydet.link</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-[4px] border border-kaydet-border overflow-hidden shadow-sm">
          {/* Header Background */}
          <div className="bg-gradient-to-r from-kaydet-brown to-kaydet-brown/90 h-40"></div>

          {/* Content */}
          <div className="px-6 sm:px-8 pb-8">
            {/* Creator Info */}
            {list.creatorName && (
              <div className="flex items-center gap-4 -mt-20 mb-6 relative z-10">
                <div className="w-20 h-20 rounded-full bg-kaydet-accent/20 flex items-center justify-center border-4 border-white">
                  <span className="text-2xl font-semibold text-kaydet-accent">
                    {list.creatorName.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-kaydet-text-primary">
                    {list.creatorName}
                  </h2>
                  {list.creatorHandle && (
                    <p className="text-kaydet-text-secondary">
                      {list.creatorHandle}
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Title and Description */}
            <div className="mb-8">
              <h1 className="text-3xl font-semibold text-kaydet-text-primary mb-3">
                {list.title}
              </h1>
              {list.description && (
                <p className="text-lg text-kaydet-text-secondary leading-relaxed">
                  {list.description}
                </p>
              )}
            </div>

            {/* Links List */}
            <div className="space-y-4">
              {list.links.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-kaydet-text-secondary">
                    Bu listede henüz link yok.
                  </p>
                </div>
              ) : (
                list.links.map((link, index) => (
                  <a
                    key={link.id}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group block p-4 border border-kaydet-border rounded-[4px] hover:border-kaydet-accent hover:bg-kaydet-light-bg transition-colors"
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-1 h-6 bg-kaydet-accent rounded-full flex-shrink-0 mt-1"></div>
                      <div className="flex-1 min-w-0">
                        <p className="text-kaydet-accent font-semibold group-hover:text-kaydet-accent-hover transition-colors truncate">
                          {index + 1}. {link.title}
                        </p>
                        {link.description && (
                          <p className="text-sm text-kaydet-text-secondary mt-1 line-clamp-2">
                            {link.description}
                          </p>
                        )}
                        <p className="text-xs text-kaydet-text-secondary mt-2 truncate opacity-70">
                          {link.url}
                        </p>
                      </div>
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          copyToClipboard(link.url, link.title);
                        }}
                        className="flex-shrink-0 p-2 hover:bg-kaydet-cream rounded-[4px] transition-colors"
                        title="Linki kopyala"
                      >
                        {copied === link.title ? (
                          <Check className="w-4 h-4 text-kaydet-accent" />
                        ) : (
                          <Copy className="w-4 h-4 text-kaydet-text-secondary hover:text-kaydet-accent" />
                        )}
                      </button>
                    </div>
                  </a>
                ))
              )}
            </div>

            {/* Stats */}
            {list.links.length > 0 && (
              <div className="mt-8 pt-8 border-t border-kaydet-border">
                <div className="flex items-center justify-between text-sm text-kaydet-text-secondary">
                  <span>Toplam {list.links.length} link</span>
                  <span>30 gün içinde sona erecek</span>
                </div>
              </div>
            )}

            {/* CTA */}
            <div className="mt-8 pt-8 border-t border-kaydet-border">
              <p className="text-center text-sm text-kaydet-text-secondary mb-4">
                Kendi listeni oluşturmak mı istiyorsun?
              </p>
              <Link
                to="/"
                className="block text-center px-6 py-2 rounded-[4px] bg-kaydet-accent text-white font-medium hover:bg-kaydet-accent-hover transition-colors"
              >
                Hemen bir liste hazırla
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
