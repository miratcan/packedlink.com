import { Link } from "react-router-dom";
import { ArrowRight, Zap, Share2, Lock, Shield, Database, LogOut } from "lucide-react";
import { PrimaryButton } from "../components/PrimaryButton";

export default function Index() {
  return (
    <div className="min-h-screen bg-kaydet-bg-warm">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-kaydet-border bg-kaydet-bg-warm">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-[4px] bg-gradient-to-br from-kaydet-accent to-kaydet-accent-hover"></div>
              <span className="font-semibold text-kaydet-text-primary">kaydet.link</span>
            </div>
            <nav className="hidden md:flex items-center gap-8">
              <a href="#neden" className="text-sm text-kaydet-text-secondary hover:text-kaydet-text-primary hover:underline underline-offset-4 transition-colors focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:ring-offset-2 focus:ring-offset-kaydet-bg-warm rounded-sm px-1">
                Neden?
              </a>
              <a href="#kimler" className="text-sm text-kaydet-text-secondary hover:text-kaydet-text-primary hover:underline underline-offset-4 transition-colors focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:ring-offset-2 focus:ring-offset-kaydet-bg-warm rounded-sm px-1">
                Kimler kullanır?
              </a>
              <PrimaryButton to="/builder" size="sm" focusRingOffset="warm">
                Başla
              </PrimaryButton>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-kaydet-brown via-kaydet-brown/97 to-kaydet-brown/95 text-white overflow-hidden pt-8 sm:pt-12 lg:pt-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 pb-16 sm:pb-24 lg:pb-28">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Left side: Content */}
            <div className="max-w-xl">
              {/* Main heading - increased size */}
              <h1 className="text-5xl sm:text-6xl lg:text-6xl font-semibold leading-tight mb-8 text-white">
                Linkleri tek sayfada topla, herkesle paylaş.
              </h1>

              {/* Subheading */}
              <p className="text-lg sm:text-xl text-white/95 mb-10 leading-relaxed">
                YouTube kursları, kahvaltı mekanları, takı ürünleri. Sık kullandığın linkleri tek adreste topla. Bio'da paylaş, hep güncel kalsın.
              </p>

              {/* CTA Buttons - consistent styling */}
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <PrimaryButton to="/builder" size="md" focusRingOffset="brown">
                  Hemen bir liste hazırla
                  <ArrowRight className="w-4 h-4" />
                </PrimaryButton>
                <button className="inline-flex items-center justify-center px-8 py-3 rounded-[4px] bg-white border border-kaydet-border text-kaydet-text-primary font-medium hover:bg-kaydet-cream transition-colors focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:ring-offset-2 focus:ring-offset-kaydet-brown">
                  Örnek listeyi gör
                </button>
              </div>

              {/* Trust indicator - improved spacing and sizing */}
              <p className="text-base text-white/85 mt-4" style={{lineHeight: '1.7'}}>
                Giriş yapmadan başla. 30 gün boyunca listeni yönet, linklerini paylaş.
              </p>
            </div>

            {/* Right side: Example Card */}
            <div className="hidden lg:block relative">
              <div className="bg-white rounded-[4px] shadow-lg overflow-hidden transform hover:scale-105 transition-transform duration-300">
                <div className="bg-gradient-to-r from-kaydet-accent to-kaydet-accent-hover h-16"></div>
                <div className="p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-full bg-kaydet-accent/20 flex items-center justify-center">
                      <span className="text-kaydet-accent font-bold text-lg">S</span>
                    </div>
                    <div>
                      <p className="font-semibold text-kaydet-text-primary text-sm">Serkan</p>
                      <p className="text-xs text-kaydet-text-secondary">@serkan_creator</p>
                    </div>
                  </div>

                  {/* Improved hierarchy: title larger, description smaller */}
                  <h3 className="text-xl font-semibold text-kaydet-text-primary mb-1">
                    Sevdiğim Türk Sanat Müziği
                  </h3>
                  <p className="text-kaydet-text-secondary text-xs mb-5 leading-relaxed">
                    En sevdiğim TSM sanatçıları ve şarkıları. Playlist eşliğinde dinle.
                  </p>

                  {/* Links with better spacing */}
                  <div className="space-y-3">
                    {[
                      { title: "Müslüm Gürses - Arzu", desc: "Klasik bir şaheser" },
                      { title: "Sibel Can - Sorma Benden", desc: "Modernin öncüsü" },
                      { title: "Ferdi Tayfur - Çiçekleri Severim", desc: "Saf duygu" },
                    ].map((link, idx) => (
                      <div key={idx} className="flex gap-3">
                        <div className="w-1 bg-kaydet-accent rounded-full flex-shrink-0 mt-0.5"></div>
                        <div className="flex-1 min-w-0">
                          <p className="text-kaydet-accent font-medium text-xs leading-tight">{link.title}</p>
                          <p className="text-xs text-kaydet-text-secondary/70 leading-tight">{link.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Bottom line - single line format without parentheses */}
                  <div className="mt-6 pt-6 border-t border-kaydet-border text-center">
                    <button className="text-xs text-kaydet-text-secondary hover:text-kaydet-accent hover:underline underline-offset-2 transition-colors font-semibold inline-flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:ring-offset-2 focus:ring-offset-white rounded-sm px-1">
                      Tümünü g��r · 6 link
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-20 right-0 w-72 h-72 bg-white/5 rounded-full blur-3xl -z-10"></div>
        <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-white/5 rounded-full blur-3xl -z-10"></div>
      </section>

      {/* Value Proposition Section - "Neden Kaydet.link?" */}
      <section id="neden" className="bg-kaydet-cream py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="mb-14 text-center">
            <h2 className="text-4xl sm:text-5xl font-semibold text-kaydet-text-primary mb-4">
              Neden Kaydet.link?
            </h2>
            <p className="text-lg text-kaydet-text-secondary max-w-2xl mx-auto">
              Linkleri paylaşmanın en basit yolu. Tek adres, sonsuz olasılık.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="p-8 rounded-[4px] bg-white border border-kaydet-border hover:border-kaydet-accent hover:shadow-lg transition-all">
              <div className="w-16 h-16 rounded-[4px] bg-kaydet-accent/25 flex items-center justify-center mb-6">
                <Zap className="w-8 h-8 text-kaydet-accent" />
              </div>
              <h3 className="text-lg font-semibold text-kaydet-text-primary mb-4">
                Linklerini bir araya topla.
              </h3>
              <p className="text-kaydet-text-secondary leading-relaxed">
                YouTube kursları, kahvaltı mekanları, favori markalar, Figma dosyaları, GitHub repo'lar. Hepsini tek sayfada topla, her linkin yanına açıklama yaz.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="p-8 rounded-[4px] bg-white border border-kaydet-border hover:border-kaydet-accent hover:shadow-lg transition-all">
              <div className="w-16 h-16 rounded-[4px] bg-kaydet-accent/25 flex items-center justify-center mb-6">
                <Share2 className="w-8 h-8 text-kaydet-accent" />
              </div>
              <h3 className="text-lg font-semibold text-kaydet-text-primary mb-4">
                Tek adres paylaş.
              </h3>
              <p className="text-kaydet-text-secondary leading-relaxed">
                Instagram bio'suna koy, YouTube açıklamasına ekle, WhatsApp grubunda paylaş. Herkes tek linke tıklar, tüm listeleri görür. Güncelledikçe herkese otomatik yansır.
              </p>
            </div>

            {/* Feature 3 - Changed from negative to positive phrasing */}
            <div className="p-8 rounded-[4px] bg-white border border-kaydet-border hover:border-kaydet-accent hover:shadow-lg transition-all">
              <div className="w-16 h-16 rounded-[4px] bg-kaydet-accent/25 flex items-center justify-center mb-6">
                <Lock className="w-8 h-8 text-kaydet-accent" />
              </div>
              <h3 className="text-lg font-semibold text-kaydet-text-primary mb-4">
                Her zaman aynı yerde bul.
              </h3>
              <p className="text-kaydet-text-secondary leading-relaxed">
                WhatsApp sohbetinde, telefonunun notlarında, Excel'de arama yapma. Sayfayı aç, linki bul, kopyala. Hepsi aynı yerde, hep güncel, hi�� kaybolmaz.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Use Cases Section - "Kimler kullanır?" */}
      <section id="kimler" className="py-16 sm:py-24 bg-kaydet-bg-warm">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="mb-20 text-center">
            <h2 className="text-4xl sm:text-5xl font-semibold text-kaydet-text-primary mb-4">
              Kimler kullanır?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Case 1 - Content creators */}
            <div className="p-6 rounded-[4px] bg-white border border-kaydet-border hover:shadow-md transition-shadow">
              <h3 className="font-semibold text-kaydet-text-primary mb-3 text-base">
                İçerik üretenler
              </h3>
              <p className="text-kaydet-text-secondary text-sm mb-5 leading-relaxed">
                YouTube, Instagram, TikTok'ta içerik üret. Videoların, ürünlerin, kursların için tek bir link ver.
              </p>
              <div className="pt-5 border-t border-kaydet-border space-y-2">
                <p className="text-xs font-semibold text-kaydet-text-primary uppercase tracking-wide">Örnek listeler</p>
                <ul className="text-xs text-kaydet-text-secondary space-y-2">
                  <li>• Kullandığım ekipmanlar</li>
                  <li>• Tavsiye ettiğim kurslar</li>
                  <li>• Müzik playlistlerim</li>
                </ul>
              </div>
            </div>

            {/* Case 2 - Place and guide sharers */}
            <div className="p-6 rounded-[4px] bg-white border border-kaydet-border hover:shadow-md transition-shadow">
              <h3 className="font-semibold text-kaydet-text-primary mb-3 text-base">
                Mekan ve rehber paylaşanlar
              </h3>
              <p className="text-kaydet-text-secondary text-sm mb-5 leading-relaxed">
                Şehir rehberi, kahvaltıcı listesi, mekan tavsiyeleri. Hepsini tek sayfada topla, gruba at.
              </p>
              <div className="pt-5 border-t border-kaydet-border space-y-2">
                <p className="text-xs font-semibold text-kaydet-text-primary uppercase tracking-wide">Örnek listeler</p>
                <ul className="text-xs text-kaydet-text-secondary space-y-2">
                  <li>• Balat'ta gezilecek mekanlar</li>
                  <li>• İzmir'de en iyi kahvaltılar</li>
                  <li>• Meditasyon stüdyolar���</li>
                </ul>
              </div>
            </div>

            {/* Case 3 - Teachers and educators */}
            <div className="p-6 rounded-[4px] bg-white border border-kaydet-border hover:shadow-md transition-shadow">
              <h3 className="font-semibold text-kaydet-text-primary mb-3 text-base">
                Öğretmenler ve eğitmenler
              </h3>
              <p className="text-kaydet-text-secondary text-sm mb-5 leading-relaxed">
                Ödev linkleri, konu anlatım videoları, PDF notlar. Hepsini tek sayfada topla, sınıfla paylaş.
              </p>
              <div className="pt-5 border-t border-kaydet-border space-y-2">
                <p className="text-xs font-semibold text-kaydet-text-primary uppercase tracking-wide">Örnek listeler</p>
                <ul className="text-xs text-kaydet-text-secondary space-y-2">
                  <li>• 8. sınıf matematik kaynakları</li>
                  <li>• Haftalık ödev linkleri</li>
                  <li>• Sınav kampı video listesi</li>
                </ul>
              </div>
            </div>

            {/* Case 4 - Team link sharers */}
            <div className="p-6 rounded-[4px] bg-white border border-kaydet-border hover:shadow-md transition-shadow">
              <h3 className="font-semibold text-kaydet-text-primary mb-3 text-base">
                Ekiple link paylaşanlar
              </h3>
              <p className="text-kaydet-text-secondary text-sm mb-5 leading-relaxed">
                Ekip dokümanları, formlar, araçlar. Hep sana sorulan linkler. Bir liste yap, herkese ver.
              </p>
              <div className="pt-5 border-t border-kaydet-border space-y-2">
                <p className="text-xs font-semibold text-kaydet-text-primary uppercase tracking-wide">Örnek listeler</p>
                <ul className="text-xs text-kaydet-text-secondary space-y-2">
                  <li>• Tüm araç ve servislerimiz</li>
                  <li>• Onboarding kaynakları</li>
                  <li>• Brand kılavuzu ve şablonlar</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="mt-12 text-center">
            <p className="text-kaydet-text-secondary text-sm">
              Buna ek olarak öğrenciler, sınav adayları ve topluluk yöneticileri gibi farklı gruplar da Kaydet.link kullanır.
            </p>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="bg-kaydet-brown text-white py-20 sm:py-28">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {/* Trust item 1 */}
            <div className="text-center md:text-left">
              <div className="inline-flex md:flex items-start gap-4 mb-3">
                <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 rounded-full bg-kaydet-bg-warm">
                  <Shield className="w-10 h-10 text-kaydet-text-primary" />
                </div>
                <h3 className="font-semibold text-4xl sm:text-5xl leading-tight">Seni takip tuzağına sokmaz</h3>
              </div>
              <p className="text-white/85 text-sm leading-relaxed">
                Takipçilerini mail listesine çevirelim, pixel atalım gibi numaralara girmez.
              </p>
            </div>

            {/* Trust item 2 */}
            <div className="text-center md:text-left">
              <div className="inline-flex md:flex items-start gap-4 mb-3">
                <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 rounded-full bg-kaydet-bg-warm">
                  <Database className="w-10 h-10 text-kaydet-text-primary" />
                </div>
                <h3 className="font-semibold text-4xl sm:text-5xl leading-tight">Verini satmaz, kiralamaz</h3>
              </div>
              <p className="text-white/85 text-sm leading-relaxed">
                Linklerini reklam hedeflemek için kullanmaz. Listelerin senindir, biz sadece saklarız.
              </p>
            </div>

            {/* Trust item 3 - More assertive version */}
            <div className="text-center md:text-left">
              <div className="inline-flex md:flex items-start gap-4 mb-3">
                <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 rounded-full bg-kaydet-bg-warm">
                  <LogOut className="w-10 h-10 text-kaydet-text-primary" />
                </div>
                <h3 className="font-semibold text-4xl sm:text-5xl leading-tight">İstediğinde çekip gidersin</h3>
              </div>
              <p className="text-white/85 text-sm leading-relaxed">
                Listelerini dışa aktar, hesabını kapat. Arkanda veri bırakmayız.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 sm:py-28 bg-kaydet-bg-warm">
        <div className="mx-auto max-w-2xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl sm:text-5xl font-semibold text-kaydet-text-primary mb-8">
            Şimdi bir liste hazırla
          </h2>
          <p className="text-lg text-kaydet-text-secondary mb-16 leading-relaxed">
            Giriş yapmadan bir sayfa oluştur. Linklerini tek adreste topla ve herkesle paylaş.
          </p>
          <PrimaryButton to="/builder" size="md" focusRingOffset="warm">
            Hemen bir liste hazırla
            <ArrowRight className="w-4 h-4" />
          </PrimaryButton>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-kaydet-brown text-white py-6 border-t border-kaydet-border">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-3">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded-[3px] bg-kaydet-accent"></div>
              <span className="font-semibold text-sm">kaydet.link</span>
            </div>
            <p className="text-xs text-white/50">
              © 2024 Kaydet.link
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
