import React from 'react';
import { Link as RouterLink } from 'react-router-dom';

interface PrimaryButtonProps {
  to: string;
  children: React.ReactNode;
  size?: 'sm' | 'md';
  className?: string;
  focusRingOffset?: 'white' | 'brown' | 'cream' | 'warm';
}

export const PrimaryButton: React.FC<PrimaryButtonProps> = ({
  to,
  children,
  size = 'md',
  className = '',
  focusRingOffset = 'white'
}) => {
  const sizeClasses = {
    sm: 'px-5 py-2 text-sm',
    md: 'px-8 py-3'
  };

  const focusOffsetClasses = {
    white: 'focus:ring-offset-white',
    brown: 'focus:ring-offset-kaydet-brown',
    cream: 'focus:ring-offset-kaydet-cream',
    warm: 'focus:ring-offset-kaydet-bg-warm'
  };

  return (
    <RouterLink
      to={to}
      className={`inline-flex items-center justify-center gap-2 ${sizeClasses[size]} rounded-[4px] bg-kaydet-accent text-white font-semibold border border-kaydet-accent-active hover:bg-kaydet-accent-hover active:bg-kaydet-accent-active transition-colors focus:outline-none focus:ring-2 focus:ring-kaydet-accent-hover focus:ring-offset-2 ${focusOffsetClasses[focusRingOffset]} ${className}`}
    >
      {children}
    </RouterLink>
  );
};
