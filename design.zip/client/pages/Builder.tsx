import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Plus, Trash2, Copy, ArrowRight } from "lucide-react";
import { PrimaryButton } from "../components/PrimaryButton";

interface LinkItem {
  id: string;
  url: string;
  title: string;
  description: string;
}

interface ListData {
  id: string;
  title: string;
  description: string;
  creatorName: string;
  creatorHandle: string;
  links: LinkItem[];
}

export default function Builder() {
  const navigate = useNavigate();
  const [list, setList] = useState<ListData>({
    id: Math.random().toString(36).substr(2, 9),
    title: "Benim Listem",
    description: "",
    creatorName: "",
    creatorHandle: "",
    links: [],
  });

  const [newLink, setNewLink] = useState({ url: "", title: "", description: "" });

  const addLink = () => {
    if (newLink.url && newLink.title) {
      setList({
        ...list,
        links: [
          ...list.links,
          {
            id: Math.random().toString(36).substr(2, 9),
            ...newLink,
          },
        ],
      });
      setNewLink({ url: "", title: "", description: "" });
    }
  };

  const removeLink = (id: string) => {
    setList({
      ...list,
      links: list.links.filter((link) => link.id !== id),
    });
  };

  const handlePublish = () => {
    // Save to session/localStorage
    sessionStorage.setItem("kaydetList", JSON.stringify(list));
    navigate("/publish");
  };

  return (
    <div className="min-h-screen bg-kaydet-cream">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-kaydet-border bg-kaydet-bg-warm">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <Link to="/" className="flex items-center gap-2 focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:ring-offset-2 rounded-[4px]">
              <div className="w-8 h-8 rounded-[4px] bg-gradient-to-br from-kaydet-accent to-kaydet-accent-hover"></div>
              <span className="font-semibold text-kaydet-text-primary">kaydet.link</span>
            </Link>
            <button
              onClick={handlePublish}
              disabled={!list.title || list.links.length === 0}
              className="inline-flex items-center justify-center gap-2 px-8 py-3 rounded-[4px] bg-kaydet-accent text-white font-semibold border border-kaydet-accent-active hover:bg-kaydet-accent-hover active:bg-kaydet-accent-active transition-colors disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-kaydet-accent-hover focus:ring-offset-2"
            >
              Yayınla
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          <div className="text-xs text-kaydet-text-secondary text-center pb-2">
            Listenin bilgilerini doldur ve yayınla
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left: Form */}
          <div className="space-y-6">
            <div className="bg-white rounded-[4px] border border-kaydet-border p-6">
              <h2 className="text-2xl font-semibold text-kaydet-text-primary mb-6">
                Liste bilgileri
              </h2>

              {/* Title Input */}
              <div className="space-y-2 mb-6">
                <label className="block text-sm font-semibold text-kaydet-text-primary">
                  Liste başlığı
                </label>
                <input
                  type="text"
                  value={list.title}
                  onChange={(e) => setList({ ...list, title: e.target.value })}
                  placeholder="Örneğin: Sevdiğim Türk Sanat Müziği"
                  className="w-full px-4 py-2 rounded-[4px] border border-kaydet-border bg-white text-kaydet-text-primary placeholder:text-kaydet-text-secondary focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:border-transparent"
                />
              </div>

              {/* Description Input */}
              <div className="space-y-2 mb-6">
                <label className="block text-sm font-semibold text-kaydet-text-primary">
                  Açıklama (opsiyonel)
                </label>
                <textarea
                  value={list.description}
                  onChange={(e) => setList({ ...list, description: e.target.value })}
                  placeholder="Bu liste hakkında bir açıklama ekle..."
                  rows={3}
                  className="w-full px-4 py-2 rounded-[4px] border border-kaydet-border bg-white text-kaydet-text-primary placeholder:text-kaydet-text-secondary focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:border-transparent resize-none"
                />
              </div>

              {/* Creator Info */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-kaydet-text-primary">
                    Adın (opsiyonel)
                  </label>
                  <input
                    type="text"
                    value={list.creatorName}
                    onChange={(e) => setList({ ...list, creatorName: e.target.value })}
                    placeholder="Örneğin: Ahmet"
                    className="w-full px-4 py-2 rounded-[4px] border border-kaydet-border bg-white text-kaydet-text-primary placeholder:text-kaydet-text-secondary focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:border-transparent"
                  />
                </div>
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-kaydet-text-primary">
                    Kullanıcı adı (opsiyonel)
                  </label>
                  <input
                    type="text"
                    value={list.creatorHandle}
                    onChange={(e) => setList({ ...list, creatorHandle: e.target.value })}
                    placeholder="@kullanıcı"
                    className="w-full px-4 py-2 rounded-[4px] border border-kaydet-border bg-white text-kaydet-text-primary placeholder:text-kaydet-text-secondary focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:border-transparent"
                  />
                </div>
              </div>
            </div>

            {/* Add Link Form */}
            <div className="bg-white rounded-[4px] border border-kaydet-border p-6">
              <h2 className="text-2xl font-semibold text-kaydet-text-primary mb-6">
                Link ekle
              </h2>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-kaydet-text-primary">
                    Link adresi
                  </label>
                  <input
                    type="url"
                    value={newLink.url}
                    onChange={(e) => setNewLink({ ...newLink, url: e.target.value })}
                    placeholder="https://örnek.com"
                    className="w-full px-4 py-2 rounded-[4px] border border-kaydet-border bg-white text-kaydet-text-primary placeholder:text-kaydet-text-secondary focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:border-transparent"
                  />
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-kaydet-text-primary">
                    Başlık
                  </label>
                  <input
                    type="text"
                    value={newLink.title}
                    onChange={(e) => setNewLink({ ...newLink, title: e.target.value })}
                    placeholder="Link başlığı"
                    className="w-full px-4 py-2 rounded-[4px] border border-kaydet-border bg-white text-kaydet-text-primary placeholder:text-kaydet-text-secondary focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:border-transparent"
                  />
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-semibold text-kaydet-text-primary">
                    Açıklama (opsiyonel)
                  </label>
                  <input
                    type="text"
                    value={newLink.description}
                    onChange={(e) => setNewLink({ ...newLink, description: e.target.value })}
                    placeholder="Bu link hakkında kısa bir açıklama"
                    className="w-full px-4 py-2 rounded-[4px] border border-kaydet-border bg-white text-kaydet-text-primary placeholder:text-kaydet-text-secondary focus:outline-none focus:ring-2 focus:ring-kaydet-accent focus:border-transparent"
                  />
                </div>

                <button
                  onClick={addLink}
                  className="w-full inline-flex items-center justify-center gap-2 px-8 py-3 rounded-[4px] bg-kaydet-accent text-white font-semibold border border-kaydet-accent-active hover:bg-kaydet-accent-hover active:bg-kaydet-accent-active transition-colors focus:outline-none focus:ring-2 focus:ring-kaydet-accent-hover focus:ring-offset-2"
                >
                  <Plus className="w-4 h-4" />
                  Linki ekle
                </button>
              </div>
            </div>
          </div>

          {/* Right: Preview */}
          <div className="sticky top-24">
            <div className="bg-white rounded-[4px] border border-kaydet-border overflow-hidden">
              <div className="bg-gradient-to-r from-kaydet-brown to-kaydet-brown/90 h-20"></div>

              <div className="p-6">
                {list.creatorName && (
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 rounded-full bg-kaydet-accent/20 flex items-center justify-center">
                      <span className="text-kaydet-accent font-semibold">
                        {list.creatorName.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      {list.creatorName && (
                        <p className="font-semibold text-kaydet-text-primary">
                          {list.creatorName}
                        </p>
                      )}
                      {list.creatorHandle && (
                        <p className="text-sm text-kaydet-text-secondary">
                          {list.creatorHandle}
                        </p>
                      )}
                    </div>
                  </div>
                )}

                <h3 className="text-2xl font-semibold text-kaydet-text-primary mb-2">
                  {list.title || "Liste başlığı"}
                </h3>

                {list.description && (
                  <p className="text-kaydet-text-secondary mb-6">
                    {list.description}
                  </p>
                )}

                <div className="space-y-3">
                  {list.links.length === 0 ? (
                    <div className="flex items-center justify-center py-12">
                      <p className="text-kaydet-text-secondary text-sm">
                        Buraya eklediğin linkler görünecek.
                      </p>
                    </div>
                  ) : (
                    list.links.map((link) => (
                      <div key={link.id} className="flex gap-3 group">
                        <div className="w-1 bg-kaydet-accent rounded-full flex-shrink-0"></div>
                        <div className="flex-1 min-w-0">
                          <a
                            href={link.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-kaydet-accent hover:text-kaydet-accent-hover font-medium text-sm block truncate"
                          >
                            {link.title}
                          </a>
                          {link.description && (
                            <p className="text-xs text-kaydet-text-secondary mt-1">
                              {link.description}
                            </p>
                          )}
                        </div>
                        <button
                          onClick={() => removeLink(link.id)}
                          className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity p-1 hover:bg-red-50 rounded text-red-500"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  )}
                </div>

                {list.links.length > 0 && (
                  <div className="mt-6 pt-6 border-t border-kaydet-border">
                    <button className="w-full inline-flex items-center justify-center gap-2 text-sm text-kaydet-accent hover:text-kaydet-accent-hover font-medium py-2 border-t-2 border-kaydet-border hover:border-kaydet-accent transition-all">
                      <Copy className="w-4 h-4" />
                      Tümünü kopyala
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
