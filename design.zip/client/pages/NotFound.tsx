import { useLocation } from "react-router-dom";
import { Link } from "react-router-dom";
import { useEffect } from "react";
import { ArrowLeft } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname,
    );
  }, [location.pathname]);

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center px-4">
      <div className="text-center">
        <div className="text-6xl font-bold text-kaydet-text-primary mb-4">
          404
        </div>
        <h1 className="text-3xl font-semibold text-kaydet-text-primary mb-2">
          Sayfa bulunamadı
        </h1>
        <p className="text-lg text-kaydet-text-secondary mb-8">
          Aradığın sayfa bulunamadı. Ana sayfaya dön ve yeniden dene.
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-[4px] bg-kaydet-accent text-white font-medium hover:bg-kaydet-accent-hover transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Ana sayfaya dön
        </Link>
      </div>
    </div>
  );
};

export default NotFound;
